package com.example.tictactoeshubh;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    int actplayer =0;
    int[] gamestatus = {2,2,2,2,2,2,2,2,2};
    int[][] winpos = {{0,1,2},{3,4,5},{6,7,8},{0,3,6},{0,4,8},{1,4,7},{2,5,8},{2,4,6}};
    boolean gameisactive = true;
     public void dropIn (View view) {
         ImageView counter = (ImageView) view;
         int tappcounter = Integer.parseInt(counter.getTag().toString());
         if (gamestatus[tappcounter] == 2 && gameisactive) {
             gamestatus[tappcounter] = actplayer;

             counter.setTranslationY(-1000f);
             if (actplayer == 0) {
                 counter.setImageResource(R.drawable.red);
                 actplayer = 1;
             } else {
                 counter.setImageResource(R.drawable.gold);
                 actplayer = 0;
             }

             counter.animate().translationYBy(1000f).rotation(360).setDuration(300);
         for(int[]wpos : winpos){
             if(gamestatus[wpos[0]] == gamestatus[wpos[1]] && gamestatus[wpos[1]] == gamestatus[wpos[2]] &&
                gamestatus[wpos[0]] != 2){
                 gameisactive = false;
                String winner="Gold";
                if(gamestatus[wpos[0]]==0){
                    winner="Red";
                }
                 TextView msg =(TextView) findViewById(R.id.wmsg);
                 msg.setText(winner +" has won !!");

             LinearLayout layout= (LinearLayout)findViewById(R.id.playAgainlayout);
             layout.setVisibility(View.VISIBLE);
             }
         }
         }else{
             boolean gameisover=true;
             for(int countstate: gamestatus){
                 if(countstate==2) gameisover = false;
             }
             if(gameisover){
                 TextView msg =(TextView) findViewById(R.id.wmsg);
                 msg.setText("Its a Draw !!");

                 LinearLayout layout= (LinearLayout)findViewById(R.id.playAgainlayout);
                 layout.setVisibility(View.VISIBLE);
             }
         }
     }

     public void playAgain(View view){
         gameisactive = true;
         LinearLayout layout= (LinearLayout)findViewById(R.id.playAgainlayout);
         layout.setVisibility(View.INVISIBLE);
         actplayer =0;
         for(int i=0;i<gamestatus.length;i++)
             gamestatus[i]=2;
         GridLayout gridLayout = (GridLayout)findViewById(R.id.gridLayout);
         for(int i=0; i < gridLayout.getChildCount() ; i++){
             ((ImageView) gridLayout.getChildAt(i)).setImageResource(0);
         }

     }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
}
